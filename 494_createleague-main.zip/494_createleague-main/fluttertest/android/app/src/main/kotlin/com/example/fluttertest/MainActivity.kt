package com.example.fluttertest

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
